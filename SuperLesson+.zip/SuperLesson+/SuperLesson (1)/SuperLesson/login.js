//Universidad Alejandro de Humboldt
//Sistema de Aprendizaje Tecnológico
//Proyecto Final: SuperLesson
//Integrantes:
//Medina Ricardo C.I: 31.550.042
//Baldomir Aaron C.I: 31.867.465
//Mosqueda Daniel C.I: 30.821.254
//Carmona Jose C.I: 31.784.045
//Moreno Abrahan C.I: 31.784.810

document.addEventListener('DOMContentLoaded', () => {

    const loginForm = document.getElementById('form-login');
    const registerForm = document.getElementById('form-registro');
    const loginSection = document.getElementById('login-section');
    const registerSection = document.getElementById('register-section');
    const linkGoRegister = document.getElementById('link-go-register');
    const linkGoLogin = document.getElementById('link-go-login');

    // Clave donde guardamos, dentro del navegador, a los usuarios que se registran
    const CLAVE_REGISTRADOS = 'usuariosRegistrados';

    // A dónde mandamos a alguien después de iniciar sesión o registrarse,
    // si su objeto de usuario no trae su propio campo "redirect".
    // OJO: ajusta esta ruta si la carpeta donde vive Lesson.html se llama distinto.
    const REDIRECT_POR_DEFECTO = 'SuperLesson/Lesson.html';

    const mostrarLogin = () => {
        loginSection.classList.remove('d-none');
        registerSection.classList.add('d-none');
    };

    const mostrarRegistro = () => {
        loginSection.classList.add('d-none');
        registerSection.classList.remove('d-none');
    };

    if (linkGoRegister) {
        linkGoRegister.addEventListener('click', (event) => {
            event.preventDefault();
            mostrarRegistro();
        });
    }

    if (linkGoLogin) {
        linkGoLogin.addEventListener('click', (event) => {
            event.preventDefault();
            mostrarLogin();
        });
    }

    // --- Utilidades para manejar los usuarios registrados en el navegador ---

    function obtenerUsuariosRegistrados() {
        try {
            const datos = localStorage.getItem(CLAVE_REGISTRADOS);
            return datos ? JSON.parse(datos) : [];
        } catch (error) {
            console.error('Error leyendo usuarios registrados:', error);
            return [];
        }
    }

    function guardarUsuarioRegistrado(usuario) {
        const registrados = obtenerUsuariosRegistrados();
        registrados.push(usuario);
        localStorage.setItem(CLAVE_REGISTRADOS, JSON.stringify(registrados));
    }

    if (!loginForm) {
        console.error('No se encontró el formulario de login en el HTML.');
        return;
    }

    // --- INICIO DE SESIÓN ---
    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const emailInput = document.getElementById('username').value.trim();
        const passwordInput = document.getElementById('password').value;

        try {
            const respuesta = await fetch('users.json', { cache: 'no-store' });

            if (!respuesta.ok) {
                throw new Error('No se pudo cargar la base de datos de usuarios');
            }

            const usuariosBase = await respuesta.json();
            const usuariosRegistrados = obtenerUsuariosRegistrados();

            // Unimos los usuarios "originales" del JSON con los que se registraron después
            const todosLosUsuarios = [...usuariosBase, ...usuariosRegistrados];

            const usuarioValido = todosLosUsuarios.find(user =>
                user.email === emailInput && user.password === passwordInput
            );

            if (usuarioValido) {
                localStorage.setItem('usuarioLogueado', usuarioValido.name);

                const destino = usuarioValido.redirect || REDIRECT_POR_DEFECTO;
                window.location.href = destino;
            } else {
                alert('Correo electrónico o contraseña incorrectos. Inténtalo de nuevo.');
            }

        } catch (error) {
            console.error('Error durante el login:', error);
            alert('Hubo un problema técnico al intentar iniciar sesión.');
        }
    });

// --- REGISTRO DE CUENTA NUEVA ---
    if (registerForm) {
        registerForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const nombre = document.getElementById('reg-name').value.trim();
            const email = document.getElementById('reg-email').value.trim();
            const password = document.getElementById('reg-password').value;

            if (!nombre || !email || !password) {
                alert('Por favor completa todos los campos.');
                return;
            }

            try {
                // Revisamos que el correo no esté ya usado 
                const respuesta = await fetch('users.json', { cache: 'no-store' });
                const usuariosBase = respuesta.ok ? await respuesta.json() : [];
                
                const correoExiste = usuariosBase.some(user => user.email === email);

                if (correoExiste) {
                    alert('Ya existe una cuenta con este correo electrónico.');
                    return;
                }

                const nuevoUsuario = { name: nombre, email: email, password: password, redirect: REDIRECT_POR_DEFECTO };

                // Enviamos los datos al servidor local
                const peticion = await fetch('http://localhost:3000/registrar', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(nuevoUsuario)
                });

                if (peticion.ok) {
                    localStorage.setItem('usuarioLogueado', nuevoUsuario.name);
                    alert('¡Cuenta creada con éxito! El archivo users.json ha sido actualizado. Iniciando sesión...');
                    window.location.href = REDIRECT_POR_DEFECTO;
                } else {
                    alert('Hubo un error al guardar en el servidor.');
                }

            } catch (error) {
                console.error('Error durante el registro:', error);
                alert('Hubo un problema técnico al crear tu cuenta.');
            }
        });
    }
}); 

