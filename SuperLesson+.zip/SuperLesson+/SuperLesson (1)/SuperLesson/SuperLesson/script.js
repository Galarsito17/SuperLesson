// ==========================================
// 1. NAVEGACIÓN Y MENÚS
// ==========================================

function showContent(id, element) {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.classList.remove('active'));
    const activeSection = document.getElementById(id);
    if (activeSection) activeSection.classList.add('active');

    const items = document.querySelectorAll('#sidebar .nav-item');
    items.forEach(item => item.classList.remove('active'));
    if (element) element.classList.add('active');
}

function toggleClasses(element) {
    const submenu = document.getElementById('classes-submenu');
    if (submenu) submenu.classList.toggle('hidden');
    if (element) element.classList.toggle('active');
}

function toggleSettings() {
    showContent('configuracion');
    const items = document.querySelectorAll('#sidebar .nav-item');
    items.forEach(item => item.classList.remove('active'));
    document.querySelector('#sidebar .nav-item[onclick="showContent(\'configuracion\', this)"]')?.classList.add('active');
}

function toggleClassMenu(event, classId) {
    event.stopPropagation();
    document.querySelectorAll('.class-more-menu').forEach(m => m.classList.remove('show'));
    const menu = document.getElementById(`more-menu-${classId}`);
    if (menu) menu.classList.toggle('show');
}

document.addEventListener('click', () => {
    document.querySelectorAll('.class-more-menu').forEach(m => m.classList.remove('show'));
});


// ==========================================
// 2. SESIÓN DE USUARIO
// ==========================================

function obtenerUsuarioLogueado() {
    const datos = localStorage.getItem('usuarioLogueado');
    if (!datos) return null;

    try {
        const parsed = JSON.parse(datos);
        return parsed && typeof parsed === 'object' ? parsed : { name: datos };
    } catch (error) {
        return { name: datos };
    }
}

function mostrarUsuarioEnNavbar() {
    const usuario = obtenerUsuarioLogueado();
    const contenedorUsuario = document.getElementById('user-area');

    if (usuario?.name && contenedorUsuario) {
        contenedorUsuario.innerHTML = `
            <div class="user-profile-nav" style="display: flex; align-items: center; gap: 10px;">
                <span class="user-name" style="font-weight: 600; color: #4a5568;">${usuario.name}</span>
                <button type="button" onclick="cerrarSesion()" class="btn-logout" style="background: none; border: none; color: #e53e3e; cursor: pointer; font-size: 0.9rem;">Cerrar sesión</button>
            </div>
        `;
    }
}

function cerrarSesion() {
    localStorage.removeItem('usuarioLogueado');
    localStorage.removeItem('usuarioLogueadoNombre');
    window.location.replace('../login.html');
}


// ==========================================
// 3. PERFILES DE PRUEBA
// ==========================================

function obtenerContenidoPorPerfil(usuario) {
    const email = usuario?.email || '';

    const perfiles = {
        'ricardo.medina@example.com': {
            nombre: 'Ricardo Medina',
            bienvenida: 'Bienvenido de nuevo, Ricardo. Tu ruta de estudio está lista.',
            clases: [
                { id: 'clasei', titulo: 'Diseño Web', descripcion: 'Explora HTML, CSS y visualización de interfaces modernas.', detalle: 'Hoy trabajarás con estructura semántica y diseño responsive.' },
                { id: 'claseii', titulo: 'JavaScript', descripcion: 'Práctica con funciones, eventos y lógica interactiva.', detalle: 'Tu reto es conectar botones, formularios y acciones del usuario.' },
                { id: 'claseiii', titulo: 'Proyectos', descripcion: 'Organiza tu trabajo final con entregas semanales.', detalle: 'Revisa avances, commits y documentación del proyecto.' }
            ]
        },
        'daniel.mosqueda@example.com': {
            nombre: 'Daniel Mosqueda',
            bienvenida: 'Hola Daniel, hoy tu panel está enfocado en programación y lógica.',
            clases: [
                { id: 'clasei', titulo: 'Algoritmos', descripcion: 'Estudia pasos lógicos y resolución de problemas.', detalle: 'Tu meta es comparar soluciones y elegir la más eficiente.' },
                { id: 'claseii', titulo: 'Base de datos', descripcion: 'Conecta tablas, consultas y relaciones de datos.', detalle: 'Revisa estructuras y consultas simples de prueba.' },
                { id: 'claseiii', titulo: 'Pensamiento crítico', descripcion: 'Desarrolla argumentos claros y presenta hallazgos.', detalle: 'Prepara una síntesis de tus aprendizajes para la semana.' }
            ]
        }
    };

    return perfiles[email] || {
        nombre: usuario?.name || 'Estudiante',
        bienvenida: 'Bienvenido a SuperLesson, tu aprendizaje está listo para empezar.',
        clases: [
            { id: 'clasei', titulo: 'Clase 1', descripcion: 'Contenido inicial adaptado a tu perfil.', detalle: 'Aquí encontrarás las actividades recomendadas para esta semana.' },
            { id: 'claseii', titulo: 'Clase 2', descripcion: 'Contenido inicial adaptado a tu perfil.', detalle: 'Aquí encontrarás las actividades recomendadas para esta semana.' },
            { id: 'claseiii', titulo: 'Clase 3', descripcion: 'Contenido inicial adaptado a tu perfil.', detalle: 'Aquí encontrarás las actividades recomendadas para esta semana.' }
        ]
    };
}


// ==========================================
// 4. PERSISTENCIA DE DATOS (LOCALSTORAGE)
// ==========================================

function loadUserData() {
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return {};
    const key = `superlesson_userdata_${usuario.email || usuario.name}`;
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : {};
}

function saveUserData(data) {
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return;
    const key = `superlesson_userdata_${usuario.email || usuario.name}`;
    localStorage.setItem(key, JSON.stringify(data));
}

function loadTasksFromStorage() {
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return [];
    const key = `superlesson_tasks_${usuario.email || usuario.name}`;
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
}

function saveTaskToStorage(task) {
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return;
    const key = `superlesson_tasks_${usuario.email || usuario.name}`;
    const arr = loadTasksFromStorage();
    arr.push(task);
    localStorage.setItem(key, JSON.stringify(arr));
}


// ==========================================
// 5. RENDERIZADO Y CONTROL DE CLASES Y TAREAS
// ==========================================

function aplicarContenidoPorPerfil(usuario) {
    const perfil = obtenerContenidoPorPerfil(usuario);
    const principalTitle = document.querySelector('#principal .card h2');
    if (principalTitle) principalTitle.textContent = `Hola, ${perfil.nombre}`;

    const principalText = document.querySelector('#principal .card p');
    if (principalText) principalText.textContent = perfil.bienvenida;

    const userData = loadUserData();
    const clasesUsuario = (userData.clases && userData.clases.length) ? userData.clases : perfil.clases;

    window.currentClasses = clasesUsuario;
    renderUserClassesUI(clasesUsuario);
}

function renderUserClassesUI(clases) {
    const clasesLista = Array.isArray(clases) ? clases : [];
    const submenu = document.getElementById('classes-submenu');
    if (submenu) submenu.innerHTML = '';

    const idsEsperados = new Set(clasesLista.map(c => c.id));
    const main = document.getElementById('main-content');
    if (main) {
        Array.from(main.querySelectorAll('section')).forEach(section => {
            if (!section.id || ['principal', 'calendario', 'pendientes', 'configuracion'].includes(section.id)) return;
            if (!idsEsperados.has(section.id)) section.remove();
        });
    }

    clasesLista.forEach((c) => {
        const div = document.createElement('div');
        div.className = 'nav-item';
        div.textContent = c.titulo;
        div.onclick = function() { showContent(c.id, this); };
        if (submenu) submenu.appendChild(div);

        if (!document.getElementById(c.id)) {
            const section = document.createElement('section');
            section.className = 'section';
            section.id = c.id;
            section.innerHTML = `
                <h1 class="page-title">${c.titulo}</h1>
                <div class="card class-card-header">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">
                        <div>
                            <h2 style="margin:0">${c.titulo}</h2>
                            <p style="margin:4px 0 0 0; color:#6c757d;">${c.descripcion || ''}</p>
                        </div>
                        <div style="position:relative;">
                            <button class="more-btn" onclick="toggleClassMenu(event, '${c.id}')">⋮</button>
                            <div id="more-menu-${c.id}" class="class-more-menu">
                                <div class="menu-item" onclick="unsubscribeFromClass('${c.id}')">Dar de baja</div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div style="display:flex; gap:8px; margin-top:10px;">
                        <button class="btn-save" onclick="openAddTaskModalById('${c.id}')">Agregar tarea</button>
                        <button class="btn-logout" onclick="eliminarTareaDeClase('${c.id}')">Eliminar última tarea</button>
                    </div>
                    <hr>
                    <div class="class-tasks" id="tasks-${c.id}"></div>
                </div>
            `;
            if (main) main.appendChild(section);
        }
    });

    refreshClassTaskLists();
}

function refreshClassTaskLists() {
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return;

    const stored = loadTasksFromStorage();
    window.tareasProximas = stored;

    document.querySelectorAll('.class-tasks').forEach(div => div.innerHTML = '');

    stored.forEach((t, index) => {
        const clases = window.currentClasses || [];
        const claseObj = clases.find(c => c.titulo === t.clase);
        
        if (claseObj) {
            const container = document.getElementById(`tasks-${claseObj.id}`);
            if (container) {
                const item = document.createElement('div');
                item.className = 'card-tarea';
                item.style.cssText = "background: #f8f9fa; border-left: 4px solid #0d6efd; padding: 10px 15px; margin-top: 10px; border-radius: 4px; display: flex; justify-content: space-between; align-items: center;";
                item.innerHTML = `
                    <div>
                        <strong style="color: #0d6efd; font-size: 0.85rem;">${t.codigo || ''}</strong>
                        <h4 style="margin: 3px 0;">${t.titulo}</h4>
                        <p style="margin: 0; font-size: 0.9rem; color: #555;">${t.descripcion}</p>
                        <small style="color: #6c757d;">📅 Entrega: ${t.fechaEntrega}</small>
                    </div>
                    <button onclick="eliminarTareaPorIndice(${index})" class="btn-logout" style="padding: 4px 8px; font-size: 0.8rem;">Eliminar</button>
                `;
                container.appendChild(item);
            }
        }
    });

    cargarCalendarioTareas();
    actualizarPendientes();
}


// ==========================================
// 6. FUNCIONALIDADES RESTAURADAS: CREAR Y UNIRSE A CLASES
// ==========================================

function getAllClasses() {
    const raw = localStorage.getItem('superlesson_all_classes');
    return raw ? JSON.parse(raw) : [];
}

function saveAllClasses(list) {
    localStorage.setItem('superlesson_all_classes', JSON.stringify(list));
}

function generateClassCode(length = 6) {
    const chars = 'ABCDEFGHIJKLMN123456789';
    let code = '';
    for (let i = 0; i < length; i++) code += chars.charAt(Math.floor(Math.random() * chars.length));
    return code;
}

function createClassFull({ nombre, section, levels, subject, room }) {
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return null;
    const all = getAllClasses();
    
    let code;
    do { code = generateClassCode(6); } while (all.find(c => c.code === code));
    
    const id = `class-${Date.now()}`;
    const clase = { id, titulo: nombre, descripcion: subject || section || '', section, levels, subject, room, code, teacher: usuario.email || usuario.name, members: [usuario.email || usuario.name] };
    
    all.push(clase);
    saveAllClasses(all);

    const user = loadUserData();
    user.clases = user.clases || [];
    user.clases.push({ id: clase.id, titulo: clase.titulo, descripcion: clase.descripcion });
    saveUserData(user);

    window.currentClasses = user.clases;
    renderUserClassesUI(window.currentClasses);
    return clase;
}

function joinClassByCode(code) {
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return { ok: false, msg: 'No hay usuario' };
    const all = getAllClasses();
    const clase = all.find(c => c.code.toUpperCase() === (code || '').toUpperCase());
    
    if (!clase) return { ok: false, msg: 'Código no válido' };

    const ident = usuario.email || usuario.name;
    clase.members = clase.members || [];
    if (!clase.members.includes(ident)) clase.members.push(ident);

    saveAllClasses(all);

    const user = loadUserData();
    user.clases = user.clases || [];
    if (!user.clases.find(c => c.id === clase.id)) user.clases.push({ id: clase.id, titulo: clase.titulo, descripcion: clase.descripcion });
    saveUserData(user);

    window.currentClasses = user.clases;
    renderUserClassesUI(window.currentClasses);
    return { ok: true, clase };
}


// ==========================================
// 7. ACCIONES DE ELIMINACIÓN Y DAR DE BAJA
// ==========================================

function unsubscribeFromClass(classId) {
    if (!confirm('¿Deseas darte de baja de esta clase?')) return;
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return;

    const userKey = `superlesson_userdata_${usuario.email || usuario.name}`;
    const raw = localStorage.getItem(userKey);
    const data = raw ? JSON.parse(raw) : {};
    
    const claseTarget = (data.clases || []).find(c => c.id === classId);
    data.clases = (data.clases || []).filter(c => c.id !== classId);
    localStorage.setItem(userKey, JSON.stringify(data));

    if (claseTarget) {
        const taskKey = `superlesson_tasks_${usuario.email || usuario.name}`;
        let tasks = loadTasksFromStorage();
        tasks = tasks.filter(t => t.clase !== claseTarget.titulo);
        localStorage.setItem(taskKey, JSON.stringify(tasks));
    }

    window.currentClasses = data.clases || [];
    aplicarContenidoPorPerfil(usuario);
    showContent('principal');
}

function eliminarTareaPorIndice(index) {
    if (!confirm('¿Deseas eliminar esta tarea?')) return;
    const usuario = obtenerUsuarioLogueado();
    if (!usuario) return;

    const taskKey = `superlesson_tasks_${usuario.email || usuario.name}`;
    let tareas = loadTasksFromStorage();
    tareas.splice(index, 1);
    localStorage.setItem(taskKey, JSON.stringify(tareas));

    refreshClassTaskLists();
}

function eliminarTareaDeClase(claseId) {
    const clases = window.currentClasses || [];
    const claseObj = clases.find(c => c.id === claseId);
    if (!claseObj) return;

    const usuario = obtenerUsuarioLogueado();
    const taskKey = `superlesson_tasks_${usuario.email || usuario.name}`;
    let tareas = loadTasksFromStorage();
    
    const index = tareas.findLastIndex(t => t.clase === claseObj.titulo);
    if (index === -1) {
        alert('No hay tareas para eliminar en esta clase.');
        return;
    }

    if (confirm(`¿Eliminar la última tarea agregada de "${claseObj.titulo}"?`)) {
        tareas.splice(index, 1);
        localStorage.setItem(taskKey, JSON.stringify(tareas));
        refreshClassTaskLists();
    }
}


// ==========================================
// 8. MODALS DE TAREAS Y VISTAS
// ==========================================

function openAddTaskModal(claseIndex) {
    const clases = window.currentClasses || [];
    const select = document.getElementById('task-subject');
    if (!select) return;

    select.innerHTML = '';
    clases.forEach((c, i) => {
        const opt = document.createElement('option');
        opt.value = c.titulo;
        opt.textContent = c.titulo;
        if (i === claseIndex) opt.selected = true;
        select.appendChild(opt);
    });

    document.getElementById('task-title').value = '';
    document.getElementById('task-desc').value = '';
    document.getElementById('task-date').value = '';

    document.getElementById('modal-add-task')?.classList.remove('hidden');
}

function openAddTaskModalById(claseId) {
    const clases = window.currentClasses || [];
    const index = clases.findIndex(c => c.id === claseId);
    openAddTaskModal(index);
}

function closeAddTaskModal() {
    document.getElementById('modal-add-task')?.classList.add('hidden');
}

function generateTaskCode(asignatura) {
    const initials = (asignatura || '').split(' ').map(w => w[0] || '').join('').toUpperCase().slice(0,4);
    const randomPart = Math.floor(10000 + Math.random() * 90000);
    return `${initials}-${randomPart}`;
}

function actualizarPendientes() {
    const pendientesSection = document.getElementById('pendientes');
    const tareas = loadTasksFromStorage();

    if (pendientesSection) {
        const card = pendientesSection.querySelector('.card');
        if (card) {
            card.innerHTML = `
                <h2>Actividades pendientes</h2>
                <p>Revisa tus tareas y actividades que faltan por completar.</p>
                <hr>
                ${tareas.length === 0 ? '<p class="text-muted">No tienes tareas pendientes.</p>' : 
                `<ul>${tareas.map(t => `<li><strong>${t.clase}</strong>: ${t.titulo} (vence ${t.fechaEntrega})</li>`).join('')}</ul>`}
            `;
        }
    }
}

function cargarCalendarioTareas() {
    const contenedor = document.getElementById('lista-tareas-calendario');
    if (!contenedor) return;

    contenedor.innerHTML = '';
    const tareas = window.tareasProximas || [];

    if (tareas.length === 0) {
        contenedor.innerHTML = "<p class='text-muted'>No tienes tareas pendientes para los próximos días.</p>";
        return;
    }

    const hoy = new Date();

    tareas.forEach(tarea => {
        const fechaTarea = new Date(tarea.fechaEntrega + 'T00:00:00');
        const diferenciaTiempo = fechaTarea - hoy;
        const diasRestantes = Math.ceil(diferenciaTiempo / (1000 * 60 * 60 * 24));

        let etiquetaUrgencia = '';
        if (diasRestantes < 0) {
            etiquetaUrgencia = '<span style="color: #dc3545; font-weight: bold;">(Vencida)</span>';
        } else if (diasRestantes === 0) {
            etiquetaUrgencia = '<span style="color: #fd7e14; font-weight: bold;">(Se entrega HOY)</span>';
        } else if (diasRestantes === 1) {
            etiquetaUrgencia = '<span style="color: #ffc107; font-weight: bold;">(Se entrega mañana)</span>';
        } else {
            etiquetaUrgencia = `<span style="color: #198754;">(Faltan ${diasRestantes} días)</span>`;
        }

        const opcionesFecha = { day: 'numeric', month: 'long', year: 'numeric' };
        const fechaFormateada = fechaTarea.toLocaleDateString('es-ES', opcionesFecha);

        contenedor.innerHTML += `
            <div class="card-tarea" style="border-left: 5px solid #0d6efd; padding: 15px; margin-bottom: 15px; background: #f8f9fa; border-radius: 4px;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <strong style="color: #0d6efd; font-size: 0.9rem;">${tarea.clase}</strong>
                    <small>${etiquetaUrgencia}</small>
                </div>
                <h3 style="margin: 5px 0; font-size: 1.2rem;">${tarea.titulo}</h3>
                <p style="margin: 5px 0; font-size: 0.9rem; color: #555;">${tarea.descripcion}</p>
                <small style="color: #6c757d; font-weight: 500;">📅 Fecha límite: ${fechaFormateada}</small>
            </div>
        `;
    });
}


// ==========================================
// 9. EVENTOS AL CARGAR LA PÁGINA (INIT)
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
    const usuario = obtenerUsuarioLogueado();

    if (!usuario) {
        window.location.replace('../login.html');
        return;
    }

    showContent('principal', document.querySelector('.nav-item'));
    mostrarUsuarioEnNavbar();
    aplicarContenidoPorPerfil(usuario);

    // Eventos del botón flotante/menú de crear y unirse
    document.addEventListener('click', (e) => {
        const menu = document.getElementById('create-join-menu');
        const btn = document.getElementById('btn-create-join');
        if (btn && (btn === e.target || btn.contains(e.target))) {
            menu?.classList.toggle('hidden');
            return;
        }
        if (menu && !menu.contains(e.target) && btn && !btn.contains(e.target)) {
            menu.classList.add('hidden');
        }
    });

    document.getElementById('menu-create')?.addEventListener('click', () => {
        document.getElementById('create-join-menu')?.classList.add('hidden');
        document.getElementById('modal-create-class')?.classList.remove('hidden');
    });

    document.getElementById('menu-join')?.addEventListener('click', () => {
        document.getElementById('create-join-menu')?.classList.add('hidden');
        document.getElementById('modal-join-class')?.classList.remove('hidden');
    });

    document.getElementById('cc-cancel')?.addEventListener('click', () => document.getElementById('modal-create-class')?.classList.add('hidden'));
    document.getElementById('join-cancel')?.addEventListener('click', () => document.getElementById('modal-join-class')?.classList.add('hidden'));

    // Formulario Crear Clase
    document.getElementById('form-create-class-full')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const nombre = document.getElementById('cc-name').value.trim();
        if (!nombre) return alert('El nombre de la clase es obligatorio');
        const section = document.getElementById('cc-section').value.trim();
        const levels = document.getElementById('cc-levels').value.trim();
        const subject = document.getElementById('cc-subject').value.trim();
        const room = document.getElementById('cc-room').value.trim();
        
        const clase = createClassFull({ nombre, section, levels, subject, room });
        alert(`Clase creada. Código de acceso: ${clase.code}`);
        document.getElementById('modal-create-class')?.classList.add('hidden');
    });

    // Formulario Unirse a Clase
    document.getElementById('form-join-class')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const code = document.getElementById('join-code').value.trim();
        if (!code) return alert('Ingresa el código de la clase');
        const res = joinClassByCode(code);
        if (!res.ok) return alert(res.msg);
        alert(`¡Te uniste con éxito a la clase ${res.clase.titulo}!`);
        document.getElementById('modal-join-class')?.classList.add('hidden');
    });

    // Formulario Agregar Tarea
    const formAdd = document.getElementById('form-add-task');
    const btnCancel = document.getElementById('btn-cancel-add');

    if (formAdd) {
        formAdd.addEventListener('submit', (e) => {
            e.preventDefault();
            const clase = document.getElementById('task-subject').value;
            const titulo = document.getElementById('task-title').value.trim();
            const descripcion = document.getElementById('task-desc').value.trim();
            const fecha = document.getElementById('task-date').value;
            const codigo = generateTaskCode(clase);

            const tarea = { clase, titulo, descripcion, fechaEntrega: fecha, codigo };
            saveTaskToStorage(tarea);
            refreshClassTaskLists();
            closeAddTaskModal();
        });
    }

    if (btnCancel) btnCancel.addEventListener('click', closeAddTaskModal);
});