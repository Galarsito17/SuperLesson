const express = require('express');
const fs = require('fs');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json()); // Permite recibir datos en formato JSON

// Ruta para recibir nuevos registros
app.post('/registrar', (req, res) => {
    const nuevoUsuario = req.body;

    // 1. Leer el archivo users.json actual
    fs.readFile('users.json', 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ mensaje: 'Error al leer la base de datos' });
        }

        let usuarios = [];
        if (data) {
            usuarios = JSON.parse(data);
        }

        // 2. Agregar el nuevo usuario al arreglo
        usuarios.push(nuevoUsuario);

        // 3. Sobreescribir el archivo users.json con los datos actualizados
        fs.writeFile('users.json', JSON.stringify(usuarios, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ mensaje: 'Error al guardar el usuario' });
            }
            res.status(200).json({ mensaje: 'Usuario registrado correctamente en users.json' });
        });
    });
});

app.listen(3000, () => {
    console.log('Servidor backend corriendo en http://localhost:3000');
});